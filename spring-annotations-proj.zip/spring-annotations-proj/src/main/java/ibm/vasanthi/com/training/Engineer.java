package ibm.vasanthi.com.training;

public interface Engineer {
	void workForWages();
}
